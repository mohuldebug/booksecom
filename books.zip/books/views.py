from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models.products import Product
from .models.category import Category
from .models.contactform import Contact
# Create your views here.

def store(request):
    products = Product.get_all_products()
    categories = Category.get_all_categories()
    categoryID = request.GET.get('category')
    if categoryID:
        products = Product.get_all_products_by_categoryid(categoryID)
    else:
        products = Product.get_all_products()

    data = {}
    data['products'] = products
    data['categories'] = categories
    return render(request, 'store.html', data)

def index(request):
    return render(request, 'index.html', {})

def contact(request):
    if request.method=="POST":
        contact = Contact()
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        number = request.POST.get('number')
        contact.name=name
        contact.email=email
        contact.number = number
        contact.subject=subject
        contact.message=message
        contact.save()
        return redirect('success')
    return render(request,'contact.html',{})

    

def success(request):
    return render(request, 'success.html',{})

def about(request):
    return render(request, 'about.html', {})

def product_detail(request, pk):
    product = Product.objects.get(pk=pk)
    context = {
        'product': product
    }
    return render(request, 'product_detail.html', context)


def search(request):
    query = request.GET['query']
    products = Product.objects.filter(name__icontains=query)
    params = {
        'products': products
    }
    return render(request, 'search.html', params)

#def base(request):
 #   categories = Category.objects.all()
  #  return render(request, 'base.html',)
